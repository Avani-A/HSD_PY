### Dictionaries and Lexicons

- __Hate Base Dictionary:__ Dictionary of words and phrases related to hate speech. Obtained from https://www.hatebase.org/
- __Positive Words Lexicon:__ lexicon of words related to positive opinion/sentiment. Obtained from https://github.com/jeffreybreen/twitter-sentiment-analysis-tutorial-201107/tree/master/data/opinion-lexicon-English
- __Negative Words Lexicon:__ lexicon of words related to negative opinion/sentiment. Obtained from https://github.com/jeffreybreen/twitter-sentiment-analysis-tutorial-201107/tree/master/data/opinion-lexicon-English
